#Database tools#

Pooling:
https://wiki.postgresql.org/wiki/Number_Of_Database_Connections
https://www.postgresql.org/docs/7.4/jdbc-datasource.html
logging and monitoring:
https://medium.com/avitotech/how-to-work-with-postgres-in-go-bad2dabd13e4


sql ORM gorm:
the default model fields are all embedded
// gorm.Model definition
type Model struct {
  ID        uint `gorm:"primary_key"`
  CreatedAt time.Time
  UpdatedAt time.Time
  DeletedAt *time.Time
}