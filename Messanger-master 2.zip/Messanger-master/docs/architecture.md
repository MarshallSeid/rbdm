messaging protocal:
investigate xmpp vs mqtt, use json and websocket for now
https://learnku.com/articles/34736

caching layer for each Thread using memcache


v0
Single instance, persistent MVC architecture

API server/controller(entry point web server):
handles all websocket connection and delegate to ThreadManager for messaging handling accross Threads

Client Connection Pool Manager:
An optimization layer that manages all client connection to dynanmic query and sheduled by ThreadManager

ThreadManger:
 manage a pool of Thread with LRU

Model:
ThreadManager: manage messages Threads and data


**Core Message Logic**



**DevOps**
release


###### **InfraStructure**

storage layer:
we will use sql(postgres to store Thread table and User_Thread table)

nosql(cassandra) to store Message table

database:
ORM choice: looking for a simple and flexible orm
https://gorm.io/
Full-Featured ORM (almost)
 Associations (Has One, Has Many, Belongs To, Many To Many, Polymorphism)
 Hooks (Before/After Create/Save/Update/Delete/Find)
 Preloading (eager loading)
 Transactions
 Composite Primary Key
 SQL Builder
 Auto Migrations
 Logger
 Extendable, write Plugins based on GORM callbacks
 Every feature comes with tests
 Developer Friendly

conclusion:
able to customize with SQL Builder
easy to run CRUD
dm migration

###### **Networking**
service networking?
rpc among microservice

###### **Cluster Management**
k8s

###### **Framework**
need:
a golang backend web api framework
a microservice framework for better communication

existing go SDK and frameworks:
for reference:
[https://medium.com/cloud-native-the-gathering/go-kit-vs-micro-vs-gizmo-comparison-what-the-internet-is-saying-5b396058c5b2][]

Gokit:
not a complete framework, the only advantage is providing a lot transportation layer utilities
logging, tracing support

Micro:
Micro empowers developers to build microservices in the cloud and beyond without worrying about managing the infrastructure.
Complete set (and essentially a “framework”) of libraries and tools
A microservices platform but is agnostic of underlying runtime (users can use Kubernetes, Mesos, Docker Swarm, etc.)
The community is more responsive
feature rich
great development environment
transparent service monitoring
Use go-kit where you want complete control. Use go-micro where you want an opinionated framework.
pluggability






[]: https://medium.com/cloud-native-the-gathering/go-kit-vs-micro-vs-gizmo-comparison-what-the-internet-is-saying-5b396058c5b2
