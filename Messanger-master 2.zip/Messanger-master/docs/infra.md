logging and Message
golang: use Package log
https://www.datadoghq.com/blog/go-logging/

for now, use revel building log framework:
https://revel.github.io/manual/logging.html
