The philosophy of microservices:
[https://micro.mu/about/][]


Services are small - fine-grained as a singular business purpose similar to unix philosophy of "Do one thing and do it well"

The organization culture should embrace automation of deployment and testing. This eases the burden on management and operations

The culture and design principles should embrace failure and faults, similar to anti-fragile systems.
We believe microservices development is the key driving force of innovation in companies like Amazon, Google and Facebook today. And now we want to share that with you.


leveraging micro service is a huge plus for my infra and devops
1. Easier to scale development - teams organise around different business requirements and manage their own services.
2. Easier to understand - microservices are much smaller, usually 1000 LOC or less.
3. Easier to deploy new versions of services frequently - services can be deployed, scaled and managed independently.
4. Improved fault tolerance and isolation - separation of concerns minimises the impact of issues in one service from another.
5. Improved speed of execution - teams deliver on business requirements faster by developing, deploying and managing microservices independently.
6. Reusable services and rapid prototyping - the unix philosophy ingrained in microservices allow you to reuse existing services and build entirely new functionality on top much quicker.

[]: https://micro.mu/about/