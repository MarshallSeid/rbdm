
1/20
User service: user management stuff

Pub/sub socket service (controller)
  server a web server to receive socket and other connection facing outside

Thread service: manage and load a pool of Thread instance
  ThreadManager: create and load a Thread upon request

1/27:
all basic workflow done.

2/4:

ORN
thread management
auth service
UI

look for better project planning



  TODO:
  look into fast message queue implementation or other ipc techniques: https://godoc.org/bitbucket.org/avd/go-ipc/mq

  look into micro server frame to incorporate: https://github.com/micro/go-micro

  better api documentation, look into swagger: https://goswagger.io/tutorial/todo-list.html


3/18
group chat works
dm chat works
all done

3/22

Since revel route is a bit confusing, separate out api server from messaging pub/sub. Look into micro api framework
capability. 
go revel is a good full stack framework, but its routing is too adhoc

