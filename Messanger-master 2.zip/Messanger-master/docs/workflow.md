****The worflow describe a flow from a user's perspective to go through how a system works****

**User Flows/Stories:**

**User Management**
CRUD
by default we create a pool of random users


**ThreadServer(an API server)**
1. A User search for a Thread:
The User can search by A thread's id, name, partial keywords and get thread gadgets return showing a brief
information about a thread

2.0 A User Create a new Thread:
A user can create a new thread by filling out all the necessary information for a Thread

2.1 A User Leave a joined Thread;

2.2 A User delete a owned Thread(prohibited and RBACed right now)

2.3 A user who is the owner of a Thread can update the Thread information

2.4 A user can join a Thread after identifying a Thread

2.5 A user is able to connect to a Thread he/she joined

2.6 A user is able to send/receive message to a connected Thread through websocket

**ThreadManager**
3. User Join a Thread for activities:
First, A user need to find a thread by searching with id, name, or partial keywords

Once a thread is identified, the user Join on the Thread with thread_id
In the meanwhile, The ThreadManager will load and schedule all necessary resource for that user session
(blocking call, sync data/metadata, update thread state, lock and modify shared Thread states)

once joined, the uesr client will hold an session of that thread and the connectionManager will
manage that connection/session.

**Thread**
4. A User can receive messages from a Thread
When the user is active in that Thread, an active Thread will handle all the incoming traffic for the user

5. A User can send messages to a Thread
When the user is active in that Thread, every message the user sends will be broadcast to all participants of the Thread
active participants will receive the messages in real time while the offline user will able to recieve the messages from
archives when they log back in


****Concepts and Dataflows:****
_ThreadManger:_
Thread realated CRUD
manage all Threads and connect a user to a Thread for communication

_Thread:_
contains all data(messages, participants)for a chatroom communication
threads create and holds session to communicate among users.
Thread is a shared resource among users.
No single user holds a Thread

Thread handling loop:
on a new incoming msg x:
boardcast msg x to all active subscribers
and put msg x into archives

The archive for a Thread is meant to store all previous msg on the current thread, and will be garabage collected and store into persistent storage periodically(for the best user experience, once an hour? could be dynanmically adjust, it's just a msg hot cache)

As a new message coming in,

it will 
- fan out to all subscribers through the event channel
- write to archive cache
- have another go routine to persist into db in paraellel

_Subscription:_
created by Thread, used by Thread and User to exchange communication data

users

original workflow

chatroom data model:

on user join a Thread:
create a
