# Thread

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** |  | [optional] [default to null]
**ThreadName** | **string** |  | [default to null]
**ParticipantsHash** | **string** |  | [optional] [default to null]
**CreatedOn** | **string** |  | [optional] [default to null]
**CreatedBy** | **string** |  | [optional] [default to null]
**Messages** | [***Message**](Message.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


