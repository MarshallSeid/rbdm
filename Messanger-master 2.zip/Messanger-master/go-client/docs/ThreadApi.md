# \ThreadApi

All URIs are relative to *http://petstore.swagger.io/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AddThread**](ThreadApi.md#AddThread) | **Post** /thread | create a new thread
[**ConnectThread**](ThreadApi.md#ConnectThread) | **Post** /thread/connect | Connect to a joined Thread
[**DeleteThread**](ThreadApi.md#DeleteThread) | **Delete** /thread | Deletes a Thread
[**FindThread**](ThreadApi.md#FindThread) | **Get** /thread/find | Finds a Thread by keywords
[**JoinThread**](ThreadApi.md#JoinThread) | **Post** /thread/join | Join a Thread
[**LeaveThread**](ThreadApi.md#LeaveThread) | **Put** /thread/leave | Leave a joined Thread
[**UpdateThread**](ThreadApi.md#UpdateThread) | **Put** /thread | Update an existing Thread


# **AddThread**
> AddThread(ctx, body)
create a new thread



### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**Thread**](Thread.md)| Thread object that needs to be added to the store | 

### Return type

 (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/xml, application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ConnectThread**
> ConnectThread(ctx, threadId)
Connect to a joined Thread

a user connect to a joined thread

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **threadId** | **int32**| The id of a thread to connect | 

### Return type

 (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/xml, application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **DeleteThread**
> DeleteThread(ctx, threadId)
Deletes a Thread



### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **threadId** | **int64**| thread id to delete | 

### Return type

 (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **FindThread**
> []Thread FindThread(ctx, keywords)
Finds a Thread by keywords

(id, name, partial keywords) and get thread gadgets return showing a brief information about a thread. The input could be either id or name/partial keywords

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **keywords** | **string**| a keywords string could be id or name, server will run inferencce | 

### Return type

[**[]Thread**](Thread.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **JoinThread**
> JoinThread(ctx, threadId)
Join a Thread

a user join a thread

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **threadId** | **int32**| The id of a thread to join | 

### Return type

 (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/xml, application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **LeaveThread**
> LeaveThread(ctx, threadId, userId)
Leave a joined Thread

a user leave a joined thread

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **threadId** | **int32**| The id of a thread to leave | 
  **userId** | **int32**| the userId of the user who is leaving | 

### Return type

 (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/xml, application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **UpdateThread**
> UpdateThread(ctx, body)
Update an existing Thread



### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**Thread**](Thread.md)| Thread object that needs to be update | 

### Return type

 (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/xml, application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

