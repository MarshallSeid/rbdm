/*
This package serve to provide any database service to other microservices
based on the traffic, this could turn into a database connection pool
*/
package db

import (
	time "time"

	backoff "github.com/cenkalti/backoff"
	"github.com/gocql/gocql"
	"github.com/jinzhu/gorm"
	_ "github.com/jinzhu/gorm/dialects/postgres"
	_ "github.com/lib/pq"
	"github.com/revel/revel"
)

var (
	DBSession    *gorm.DB
	NosqlSession *gocql.Session
)

func setupNoSql() {
	var err error
	// init cassandra
	// connect to the cluster
	cassandraHost := revel.Config.StringDefault("cassandra.host", "127.0.0.1")
	cluster := gocql.NewCluster(cassandraHost)
	cluster.Keyspace = revel.Config.StringDefault("cassandra.KEYSPACE", "test")
	cluster.Consistency = gocql.Quorum
	nosqlSession, _ := cluster.CreateSession()

	// Wrap session on creation, gocqlx session embeds gocql.Session pointer.
	NosqlSession, err = gocqlx.WrapSession(cluster.nosqlSession())
	if err != nil {
		t.Fatal(err)
	}

	// graceful shutdown db connections
	revel.OnAppStop(func() {
		revel.RevelLog.Info("Closing the database (from module)")
		nosqlSession.Close()
		if !nosqlSession.Closed() {
			revel.AppLog.Error("Failed to close the database")
		}
	})
}

func setupSql() {

	// init postgres
	/*
	   Google's SRE book suggests maximum of 3 attempts with randomized exponential back off,
	   with a global per-process retry budget of 10%. If you start failing more than 10% of your
	    calls, stop retrying.
	*/
	revel.RevelLog.Info("Opening the database (from module)")
	operation := func() error {
		var err error
		DBSession, err = gorm.Open("postgres", "host=myhost port=myport user=gorm dbname=gorm password=mypassword")
		if err != nil {
			return err
		}
		return nil
	}

	err := backoff.Retry(operation, backoff.NewExponentialBackOff())

	if err != nil {
		revel.AppLog.Panic("postgres connection failure with ", "error: ", err)
		return
	}
	// setup database pooling
	// use the current fix: https://github.com/jinzhu/gorm/issues/246
	DBSession.DB().SetMaxIdleConns(revel.Config.IntDefault("sql.max_idle", 0))
	DBSession.DB().SetMaxOpenConns(revel.Config.IntDefault("sql.max_open", 0))
	duration, _ := time.ParseDuration(revel.Config.StringDefault("max_life_time", "5s"))
	DBSession.DB().SetConnMaxLifetime(duration)

	// graceful shutdown db connections
	revel.OnAppStop(func() {
		revel.RevelLog.Info("Closing the database (from module)")
		if err := DBSession.Close(); err != nil {
			revel.AppLog.Error("Failed to close the database", "error", err)
		}
	})
}

func init() {

	/* TODO: better db management
	   revel.Filters = []revel.Filter{
	       revel.PanicFilter,             // Recover from panics and display an error page instead.
	       ... snipped ...
	       revel.CompressFilter,          // Compress the result.
	       revel.ActionInvoker,           // Invoke the action.
	   }
	*/

	/*
	  TODO: init db on app start
	*/

	// // Migrate the schema
	// db.AutoMigrate(&Product{})
	// // Create
	// db.Create(&Product{Code: "L1212", Price: 1000})
	//
	// // Read
	// var product Product
	// db.First(&product, 1) // find product with id 1
	// db.First(&product, "code = ?", "L1212") // find product with code l1212
	//
	// // Update - update product's price to 2000
	// db.Model(&product).Update("Price", 2000)
	//
	// // Delete - delete product
	// db.Delete(&product)

	// setup db connections, need to wait or not
	go setupSql()

	// TODO: get nosql strat, all use sql for simplicity
	// go setupNoSql()

}
