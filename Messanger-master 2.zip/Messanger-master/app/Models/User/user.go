/*
This user package contains all user relate data model interface

Auth has two models, model AuthIdentityModel is used to save login information, model UserModel is used to save user information.
The reason we save auth and user info into two different models, as we want to be able to link a user to mutliple auth info records, so a user could have multiple ways to login.
*/

package user

import (
	db "Messanger/app/db"
	"fmt"
	"net/http"
	"strconv"
	"time"

	"github.com/jinzhu/gorm"
	"github.com/twinj/uuid"
)

/*
A User is a uber object model
*/
type User struct {
	gorm.Model

	id       string
	username string `gorm:"type:varchar(256);unique_index"`
	// password []byte
	first_name  string    `gorm:"type:varchar(128);unique_index"`
	last_name   string    `gorm:"type:varchar(128);unique_index"`
	status      int       `gorm:"type:SMALLINT;not null"`
	creasted_on time.Time `gorm:"type:date;not null"`
	updated_on  time.Time `gorm:"type:date;not null;DEFAULT CURRENT_DATE"`
	Email       string    `gorm:"type:varchar(100);unique_index"`

	threads Thread.Thread

	// password
	// Role         string  `gorm:"size:255"` // set field size to 255
	// MemberNumber *string `gorm:"unique;not null"` // set member number to unique and not null
	// Num          int     `gorm:"AUTO_INCREMENT"` // set num to auto incrementable
	// Address      string  `gorm:"index:addr"` // create index with name `addr` for address
	// IgnoreMe     int     `gorm:"-"` // ignore this field
}

type UserThreadModel struct {
	user_id          uuid.UUID `gorm:"type:uuid;"`
	thread_id        uuid.UUID `gorm:"type:uuid;"`
	last_read_msg_id uuid.UUID `gorm:"type:uuid;"`
}

func CreateRandomUser() User {
	return User{}
}

// // SetNewPassword set a new hashsed password to user
// func (user *User) SetNewPassword(passwordString string) {
// 	bcryptPassword, _ := bcrypt.GenerateFromPassword([]byte(passwordString), bcrypt.DefaultCost)
// 	user.HashedPassword = bcryptPassword
// }

func allUsers() User {
	var users []User
	db.dbSession.Find(&users)
	fmt.Println("{}", users)
	return users
}

func newUser(input map[string]interface{}) User {
	name := c.Param("name")
	email := c.Param("email")
	user := User{Name: "Jinzhu", Age: 18, Birthday: time.Now()}

	db.NewRecord(user) // => returns `true` as primary key is blank

	return db.Create(&user)
}

func deleteUser(db *gorm.DB) func(echo.Context) error {
	return func(c echo.Context) error {
		name := c.Param("name")

		var user User
		db.Where("name = ?", name).Find(&user)
		db.Delete(&user)

		return c.String(http.StatusOK, name+" user successfully deleted")
	}
}

func updateUser(db *gorm.DB) func(echo.Context) error {
	return func(c echo.Context) error {
		name := c.Param("name")
		email := c.Param("email")
		var user User
		db.Where("name=?", name).Find(&user)
		user.Email = email
		db.Save(&user)
		return c.String(http.StatusOK, name+" user successfully updated")
	}
}

func usersByPage(db *gorm.DB) func(echo.Context) error {
	return func(c echo.Context) error {
		limit, _ := strconv.Atoi(c.QueryParam("limit"))
		page, _ := strconv.Atoi(c.QueryParam("page"))
		var result []User
		db.Limit(limit).Offset(limit * (page - 1)).Find(&result)
		return c.JSON(http.StatusOK, result)
	}
}

func handleRequest(db *gorm.DB) {
	e := echo.New()

	e.GET("/users", allUsers(db))
	e.GET("/user", usersByPage(db))
	e.POST("/user/:name/:email", newUser(db))
	e.DELETE("/user/:name", deleteUser(db))
	e.PUT("/user/:name/:email", updateUser(db))

	e.Logger.Fatal(e.Start(":3000"))
}

func init() {
	//
}
