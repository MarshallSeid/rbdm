/*
package Message contianer all model for events and message
should use nosql but use sql now for simplicity
*/
package message

import (
	"github.com/satori/go.uuid"
  "time"
  db "Messanger/app/db"
  "github.com/jinzhu/gorm"
)

// This will contains all the Thread related data structures

type Event struct{
  Type      string  // "join", "leave", "msg"
  User        string
  Timestamp   int   // Unix timestamp (secs)
}

func newEvent(typ, user string) Event{
  return Event{typ, user, int(time.Now().Unix())}
}

// make Message to be a type of event
// message is stored in nosql
// only Message will be persisted in DB
type Message struct{
  gorm.Model
  Event
  Content    string   `gorm:"type:text`
  threadID  uuid.UUID `gorm:"type:UUID;NOT NULL"`
  creatorID uuid.UUID `gorm:"type:UUID;NOT NULL"`
}

func newMessage(userId, msg string) Message{
  return Message{
    Event{
      "msg", 
      userId, 
      int(time.Now().Unix()),
    }, 
    "", 
    msg,
  }
}

func persistMessage(msg Message) {
  m := {
    "Michał",
    "Matczuk",
    []string{"michal@scylladb.com"},
  }
  q := session.Query(personTable.Insert()).BindStruct(p)
  if err := q.ExecRelease(); err != nil {
    t.Fatal(err)
  }
}

// loadMsgStartRange load messages for the threadID in range (msgFromID, msgToID)
func loadMsgStartRange(msgFromID string, msgToID string, threadID string) chan Event {
  return make(chan Event)
}