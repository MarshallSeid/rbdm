/*
ThreadManager: create and load a Thread upon request
it will preload most popular thread
and load a Thread on demand
ThreadManager is singleton
It manages and open all public facing thread related apis
*/

package thread

import (
	"Messanger/app/db"
	"fmt"
	"log"
	"sync"
)

var instance_lock sync.RWMutex

type ThreadManager struct {
	// a map of thread_id -> Thread object
	activeThreads sync.Map
	dbConnection  db.DBConnection
}

var mainThreadManager *ThreadManager

// CreateThreadManager create ThreadManager and preallocate threads
func CreateThreadManager() *ThreadManager {
	// OPTIMIZE: pre load most popular Threads
	log.Info("Initilize a single ThreadManger Instance!")
	mainThreadManager = new(ThreadManager{})
	return mainThreadManager
}

// static getThreadManager that will get a singleton ThreadManger
func GetThreadManager() *ThreadManager {
	// start a single instance of ThreadManager
	instance_lock.RLock()
	defer instance_lock.RUnlock()
	if !mainThreadManager {
		return CreateThreadManager()
	} else {
		return mainThreadManager
	}
}

// ThreadManager Thread CRUD
func (th *ThreadManager) findThreadById(threadId string) *Thread {

	// lookup in cache if the thread is already active
	if val, ok := th.activeThreads.Load(threadId); ok {
		return val
	} else {
		// do a database query and construct a thread object
		newThread := th.LoadThread(findThreadById(threadId))
		this.activeThreads.store(thread_id, newThread)
		return newThread
	}
}

func (th *ThreadManager) FindThreadByName(name string) *Thread {
	return db.dbSession.Where("thread_name = ?", name).First(&user)
}

// loadThread will load all thread related netadata in memory
// this will load a Thread Instance with all its metadata from data store

func (th *ThreadManager) LoadThread(thread_id string) *Thread {
	var thread Thread
	db.dbSession.First(thread.threadData, threadID)
	go start()
	return thread
}

// createThread create a Thread , TODO: think about the interface to create a thread
func (th *ThreadManager) CreateThread(tm *ThreadModel) (*Thread, error) {
	var newThread = new(Thread{
		threadData: tm,
	})

	if db.dbSession.NewRecord(tm) {
		db.dbSession.Create(tm)
		return newThread, nil
	} else {
		// already exit
		return nil, fmt.Errorf("Thread model already exits: v% \n", tm)
	}
}

// updateThread
func (th *ThreadManager) UpdateThread(tm *ThreadModel) (*Thread, error) {
	// update in database
	// Update multiple attributes with `struct`, will only update those changed & non blank fields
	db.dbSession.Model(tm).Updates(*tm)

	// update in memory?

}

// deleteThread
func (th *ThreadManager) deleteThread(tm *ThreadModel) {
	db.Delete(tm)
	if val, ok := th.activeThreads.Load(tm.id); ok {
		th.activeThreads.Delete(tm.id)
	}
}

func init() {
	// bootstrap ThreadManger
	GetThreadManager()
}
