package utils

import "crypto/sha512"

func generateHash(int length, data []byte) [Size]byte{
  switch length{
    case 512:
      return Sum512(data)
    case 256:
      return Sum512_256(data)
    default:
      return nil
  }
}
