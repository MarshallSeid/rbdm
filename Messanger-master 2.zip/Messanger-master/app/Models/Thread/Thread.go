package thread

import (
	"sync"

	"github.com/jinzhu/gorm"
	uuid "github.com/satori/go.uuid"
)

// all the global variables

const archiveSize = 10
const BUFFSIZE = 10

/*
The Subscription object model
Subscription is a user's connection to a Thread
Subscription serves as user's receiption message connection
for sending connection, use thread action
*/
type Subscription struct {
	thread    *Thread
	userID    string
	Archive   []Event      // all archive event
	NewEvents <-chan Event // new inncoming evnets buffered per session
}

// Cancel will stop user session buffer from listening to new events
func (s *Subscription) Cancel() {
	s.thread.subscribers.Delete(s.user_id)
	drain(s.NewEvents) // Drain it, just in case there was a pending publish.
}

/*
Thread Model is a object relation model type for Thread
this is the model save in the database for Thread
*/
type ThreadModel struct {
	ID          uuid.UUID `gorm:"type:uuid;PRIMARY_KEY"`
	thread_name string    `gorm:"type:varchar(256);NOT NULL"`
	// https://dba.stackexchange.com/questions/115271/what-is-the-optimal-data-type-for-an-md5-field
	participants_hash uuid.UUID `gorm:"type:UUID;NOT NULL"`
}

/*
Thread struct will container all thread related metadata
message - a list of messages that create for this message Subscription, TODO: make it LRU cache
participants - a list of users who are active in the Thread right now
*/
type Thread struct {
	gorm.Model

	// ORM
	threadData *ThreadModel

	// metadata
	// messages list.List 	Don't need a message queue, we fan out right away?

	// hold active user subscription session: user_id -> Subscription
	// need threadsafe concurrent map
	subscribers sync.Map //map[string]*Subscription

	archive []Event // a array of Event, hold the thread archive messages, need to persist to db, it's served as a msg hot cache

	archiveLock sync.RWMutex // lock for archive

	// Send events here to publish them
	publish chan Event
}

// Thread Constructors

// This is primiary used by system to generate seed threads
// better to use a build pattern to build up the fields
// not persisted in db, only in memory for testing
// http://blog.ralch.com/tutorial/design-patterns/golang-builder/
func NewThread(tm *ThreadModel) *Thread {
	new_thread = new(Thread{
		threadData: tm,
	})
	go start()
	return new_thread
}

// TODO: handle Thread graceful shut down
/*
finish up all active connections
persist all archives
*/

// read and write thread safe method for archive, currently use RWLock
// TODO: more fine grain lock, a concurrent list for archive read and write
func (t *Thread) readArchive(read func()) {
	t.archiveLock.RLock()
	defer t.archiveLock.RUnlock()
	read()
}

// take a snapshot of archive for read on non critical read
func (t *Thread) ReadArchiveOnCopy(read func(archive []Event)) {
	r.archiveLock.RLock()
	defer t.archiveLock.RUnlock()

	copyArchive := make([]Event, len(t.archive), cap(t.archive))
	copy(copyArchive, t.archive)
	read(copyArchive)
}

func (t *Thread) writeArchive(write func()) {
	t.archiveLock.Lock()
	defer t.archiveLock.Unlock()
	// archive cache invalidation on write
	if t.archive.Len() >= archiveSize {
		t.archive.Remove(t.archive.Front())
	}
	write()
}

// Thread Actiions Events
func (t *Thread) Join(user_id string) {
	t.publish <- newEvent("join", user_id, "")
}

func (t *Thread) Leave(user_id string) {
	t.publish <- newEvent("leave", user_id, "")
}

// Say is where user post Message
func (t *Thread) Say(user_id, message string) {
	publish <- newMessage(user_id, message)
}

// subscribe is triggered when a user subscripe to a Thread as a mean to initilize user connection
// The user will receive all active messages and older messages haven't read from
// database
func (t *Thread) Subscribe(user_id string) Subscription {
	/* this will create a subscription request and send it to subscribe channel
	to properly initialize the intial states

	current improvement: no need the extra overhead to create a subscription request
	to handle a new subscription, just init here and use synchronization primitive
	to control archive
	*/
	var archiveEvents []Event

	t.ReadArchiveOnCopy(func(archive []Event) {
		archiveEvents = append(archiveEvents, archive)
	})

	subcriberChannel := make(chan Event, BUFFSIZE)
	t.subscribers.Store(user_id, subcriberChannel)

	return Subscription{
		t,
		user_id,
		archiveEvents,
		subcriberChannel,
	}
}

// RetriveUnReadMessage handles retrieving unread messages for a user in the current Trhead
// from both Thread archive(cache) and persistent storage
/*
TODO: might change behavior in the future, right now chose the most cost efficient way #3 since we don't care about that much
How can we figure out what's the last user read message?
1. we can store a user last_read message idx per user per thread
pro - accurate and easy pin down where user read left off
	- work on any scenario
cons:
- too expensive with the extra meta data store per user per thread
- extra database lookup on user join request

2. we can store user last login/active time stamp in User table, so that
we can use that time to search and figure out the last unread message
pro: - less expensive
	 - some what accurate if no clock skew
con:
- not 100% accurate bc the clock sync among clients and servers
- still need extra storage but less

3. Just find last unread purely based off the message loaded already from the
client side.
pro:
- no extra anything
- easy and fast to identify
- accurate
con:
- accurate but not reliable if on web but mobile is fin(better)

4. leverage a norification feature to derive last unread msg per user per thread
pro:
	- less expensive
	- accurate
con:
	- too complex at this point (no notification service yet)
	- still extra cost

*/
// func (t *Thread) RetrievUnReadMessage(lastReadMsgID string) chan Message{

// 	var chan Message catchMsg

// 	// retrieve from thread archive(cache)
// 	var archive_head_ID string
// 	readArchive(func(){
// 		archive_head_ID = t.archive.Front.Value.ID
// 	})

// 	if(lastReadMsgID.Compare(archive_head_ID) >= 0){
// 		// msgs are at least from archives
// 		// load subsequence msg from archives from lastReadMsgID
// 		go ReadArchiveOnCopy(func(archive []Event){
// 			// TODO: binary search on the archive
// 			for _, event := range archive {
// 				if(event.ID.Compare(lastReadMsgID) > 0){
// 					event -> catchMsg
// 				}
// 			}
// 		})
// 	}else{
// 		// retrieve from DB if necessary
// 		catchMsg = Message.LoadMsgStartFrom(lastReadMsgID, archive_head_msg_id)
// 	}

// 	return catchMsg
// }

// This start handles thread server side processsing loop
func (t *Thread) start() {
	// kick start multiple event processor on parellel
	for {
		select {
		// case ch := <-subscribe:
		// 	/*
		// 	for each new incoming subscription:
		// 	initialize a Subscription object
		// 		append the user to subscribers list
		// 		add archive message and send to user
		//
		// 	here using subscribe to do blocking read on archive, we can just use a lock
		//
		// 	*/
		// 	var events []Event
		// 	for e := archive.Front(); e != nil; e = e.Next() {
		// 		events = append(events, e.Value.(Event))
		// 	}
		// 	subscriber := make(chan Event, 10)
		// 	subscribers.PushBack(subscriber)
		//
		// 	ch <- Subscription{events, subscriber}

		// only handling new publish events
		/*

			As a new message coming in,
			it will
			- fan out to all subscribers through the event channel
			- have another go routine to persist into db in paraellel
			- write to archive cache

		*/
		case event := <-publish:

			// fan out to all subscribers through the event channel
			t.subscribers.Range(func(key, value interface{}) bool {
				value.(chan Event) <- event
				return true
			})

			// have another go routine to persist into db in paraellel
			if event.Type == "msg" {
				go persistMessage(event)
			}

			// awrite to archive cache and invalidation
			writeArchive(func() {
				t.archive.PushBack(event)
			})

			// case unsub := <-unsubscribe:
			// 	for ch := subscribers.Front(); ch != nil; ch = ch.Next() {
			// 		if ch.Value.(chan Event) == unsub {
			// 			subscribers.Remove(ch)
			// 			break
			// 		}
			// 	}
		}
	}
}

// Helpers

// Drains a given channel of any messages.
/*
 TODO: find better way to close channel on the receiver side to node panic the
 sender sending msg to each subscription
 for reference: https://go101.org/article/channel-closing.html
*/
func drain(ch <-chan Event) {
	for {
		select {
		case _, ok := <-ch:
			if !ok {
				return
			}
		default:
			return
		}
	}
}
