package thread

import (
	"testing"
	"time"

	"github.com/twinj/uuid"
)

func testThreadFlow(t *testing.T) {

	// generate a test thread
	test_thread_id := uuid.NewV4()
	thread_owner_id := uuid.NewV4()

	tm := new(ThreadModel{
		test_thread_id,
		"test_thread_1",
		uuid.NewV4(),
		time.Now(),
		thread_owner_id,
	})

	testThread := NewThread(tm)

	testUserID := uid.NewV4()
	testSub := testThread.Subscribe(testUserID)
	defer testSub.Cancel()

	testThread.Joi(testUserID)
	defer user_thread.Leave(user_id)

}

func testSubscribe(t *testing.T) {

}

func init() {
	// preping

}

// use it for thread related testing
// func TestMain(m *testing.M) {
// 	// call flag.Parse() here if TestMain uses flags
// 	os.Exit(m.Run())
// }
