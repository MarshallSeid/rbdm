package auth

// import (
// 	"time"

// 	"github.com/qor/auth"
// 	"github.com/qor/auth/authority"
// 	"github.com/qor/auth/providers/facebook"
// 	"github.com/qor/auth/providers/github"
// 	"github.com/qor/auth/providers/google"
// 	"github.com/qor/auth/providers/twitter"
// 	"github.com/qor/auth_themes/clean"
// 	"github.com/qor/qor-example/config"
// 	"github.com/qor/qor-example/config/bindatafs"
// 	"github.com/qor/qor-example/models/users"
// 	"github.com/qor/render"

//   	user "app/Modes/User"
//   	db "app/db"
// )

// var (
// 	// You are not necessary to set AuthIdentityModel, Auth has a default definition of AuthIdentityModel, in case of you want to change it, make sure you have auth_identity.Basic embedded, as Auth assume you have same data structure in your database, so it could query/create records with SQL.
// 	// Migrate AuthIdentity model, AuthIdentity will be used to save auth info, like username/password, oauth token, you could change that.
// 	// Here is the basic AuthIdentity model
// 	// type Basic struct {
//   //   Provider          string // phone, email, wechat, github...
//   //   UID               string `gorm:"column:uid"`
//   //   EncryptedPassword string
//   //   UserID            string
//   //   ConfirmedAt       *time.Time
// 	// }

// 	gormDB.AutoMigrate(&auth_identity.AuthIdentity{})

// 	// Auth initialize Auth for Authentication
// 	Auth = clean.New(&auth.Config{
// 		DB:         db.dbSession,
// 		Mailer:     config.Mailer,
// 		Render:     render.New(&render.Config{AssetFileSystem: bindatafs.AssetFS.NameSpace("auth")}),
// 		UserModel:  user.User{},
// 		Redirector: auth.Redirector{RedirectBack: config.RedirectBack},
// 	})

// 	// Allow use Github
//   Auth.RegisterProvider(github.New(&github.Config{
//     ClientID:     "github client id",
//     ClientSecret: "github client secret",
//   }))

//   // Allow use Google
//   Auth.RegisterProvider(google.New(&google.Config{
//     ClientID:     "google client id",
//     ClientSecret: "google client secret",
//   }))

//   // Allow use Facebook
//   Auth.RegisterProvider(facebook.New(&facebook.Config{
//     ClientID:     "facebook client id",
//     ClientSecret: "facebook client secret",
//   }))

//   // Allow use Twitter
//   Auth.RegisterProvider(twitter.New(&twitter.Config{
//     ClientID:     "twitter client id",
//     ClientSecret: "twitter client secret",
//   }))

// 	// Authority initialize Authority for Authorization
// 	Authority = authority.New(&authority.Config{
// 		Auth: Auth,
// 	})
// )

// func init() {
// 	Auth.RegisterProvider(github.New(&config.Config.Github))
// 	Auth.RegisterProvider(google.New(&config.Config.Google))
// 	Auth.RegisterProvider(facebook.New(&config.Config.Facebook))
// 	Auth.RegisterProvider(twitter.New(&config.Config.Twitter))

// 	Authority.Register("logged_in_half_hour", authority.Rule{TimeoutSinceLastLogin: time.Minute * 30})
// }
