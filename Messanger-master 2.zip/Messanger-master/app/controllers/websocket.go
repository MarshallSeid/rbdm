package controllers

import (
	"github.com/revel/revel"

	"github.com/revel/examples/chat/app/chatroom"
	"Messanger/app/Models/Thread"
)

// WebSocket A websocket client struct
type WebSocket struct {
	*revel.Controller
}

// Room renders a room
func (c WebSocket) Room(user string) revel.Result {
	return c.Render(user)
}

func (c WebSocket) RoomRouting(user_id string, thread_id string,
	ws revel.ServerWebSocket) revel.Result {

	// validation
	c.Validation.Required(user_id).Message("user_id is required.")
	c.Validation.Required(thread_id).Message("thread_id is required.")
	// Handle errors
	if c.Validation.HasErrors() {
		c.Validation.Keep()
		c.FlashParams()
		return c.Redirect(Sample1.Index)
	}

	// Make sure the websocket is valid.
	if ws == nil {
		return nil
	}

	// find the thread to join
	user_thread := (Thread.GetThreadManager()).findThreadById(thread_id, user_id)

	// route the user to its thread
	// start a subscription, use subcription as the entrance to thread
	// Subscribe will setup a user's access to a Thread
	subscription := thread.Subscribe(user_id)
	defer subscription.Cancel()

	// Join the room, send a joint event
	user_thread.Join(user_id)
	defer user_thread.Leave(user_id)


	// TODO: add logic here to send older message from db before archives
	// TODO: paganation
	// user_thread.findAllPrevUnReadDBMsg()

	// Receive the archive and send to front end, right now just send whatever is in the archive cacahe
	for _, event := range subscription.Archive {

		if ws.MessageSendJSON(&event) != nil {
			// They disconnected
			return nil
		}
	}

	// After all the Thread setup is done, we register event loop for sending
	// and receiving data for the user

	// handle sending new msg from the current user to the chat room
	// In order to select between websocket messages and subscription events, we
	// need to stuff websocket events into a channel.
	// newMessages := make(chan string)

	go func() {
		var msg string
		for {
			err := ws.MessageReceiveJSON(&msg)
			if err != nil {
				close(newMessages)
				return
			}
			//newMessages <- msg
			user_thread.Say(user_id, msg)
		}
	}()


	// handle receiving events from chat room and send to the current user's view
	for {
		select {
		case event := <-subscription.NewEvents:
			if ws.MessageSendJSON(&event) != nil {
				// They disconnected.
				return nil
			}
		// case msg, ok := <-newMessages:
		// 	// If the channel is closed, they disconnected.
		// 	if !ok {
		// 		return nil
		// 	}
		//
		// 	// Otherwise, say something.
		// 	chatroom.Say(user, msg)
		}
	}

	return nil

}
