/* ---------------------------------------------------------------------- */
/* Add table "User"                                                      */
/* ---------------------------------------------------------------------- */
CREATE TABLE IF NOT EXISTS users (
    id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
    username CHARACTER VARYING(256)  NOT NULL UNIQUE,
    password CHARACTER VARYING(512)  NOT NULL,
    first_name CHARACTER VARYING(128)  NOT NULL,
    last_name CHARACTER VARYING(128)  NOT NULL,
    status SMALLINT NOT NULL,
    created_on DATE NOT NULL,
    updated_on DATE NOT NULL DEFAULT CURRENT_DATE,
    email NVARCHAR(255),UNIQUE
);


/* ---------------------------------------------------------------------- */
/* Add table "Thread"                                                      */
/* ---------------------------------------------------------------------- */
CREATE TABLE IF NOT EXISTS threads (
    id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
    thread_name varchar(256)  NOT NULL,
    participants_hash varchar(512)  NOT NULL, /* to avoid duplicate threads*/
    created_on date NOT NULL,
    created_by uuid ,
    FOREIGN KEY (user_id) REFERENCES
);
/* ---------------------------------------------------------------------- */
/* Add table "UserThread"                                                      */
/* ---------------------------------------------------------------------- */
CREATE TABLE IF NOT EXISTS user_thread (
  user_id uuid  NOT NULL,
  thread_id uuid NOT NULL,
  last_read_msg_id uuid NOT NULL
);


/* ---------------------------------------------------------------------- */
/* Add table "Message"  use sql for temp                                                      */
/* ---------------------------------------------------------------------- */
CREATE TABLE  messages (
  id INT PRIMARY KEY,
  thread_id INT,
  creator_id INT,
  content TEXT,
  created_at TIMESTAMP,
);

